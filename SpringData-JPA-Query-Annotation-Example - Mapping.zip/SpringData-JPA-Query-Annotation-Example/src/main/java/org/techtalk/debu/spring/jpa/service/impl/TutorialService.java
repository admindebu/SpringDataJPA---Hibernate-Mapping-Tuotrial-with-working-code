package org.techtalk.debu.spring.jpa.service.impl;

public interface TutorialService {

}
